# Dark-FB v1.7
<br>
Username : asulokentod<br>
Password : rezatampans<br><br>
pkg install python2<br>
pkg install git<br>
git clone https://github.com/rezadkim/dark-fb<br>
cd dark-fb<br>
pip2 install requests<br>
pip2 install mechanize<br>
python2 dark.py<br>
<br>
